# dcmnt_e2fsprogs
An exercise related to ext4 and the helpertools from the e2fsprogs package.
